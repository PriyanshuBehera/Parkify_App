*****READ ME*******


1) To install app:
     
Run the apk file "app-debug.apk"

2) To see the source-code and xml files of the application:

Select the zip file “Parkify”, right click and extract the folder to a desired location.

Open Android Studio.

Select "Open" option under the File section.

Select the extracted folder name.

Select “layout” option under the “res” folder in the app drop down list to see the app’s design.

Select com.example.Parkify folder inside the “java” folder in the app drop down-list to see the backend code.

Plug in your phone with USB debugging enabled and use “Run app” option under the Run section to run the app.